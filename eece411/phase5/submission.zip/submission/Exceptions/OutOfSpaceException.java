package phase2Pack.Exceptions;

public class OutOfSpaceException extends Exception
{
}
