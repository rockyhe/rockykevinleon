package phase2Pack.Exceptions;

public class SystemOverloadException extends Exception
{
}
