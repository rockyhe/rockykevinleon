package phase2Pack.Exceptions;

public class UnrecognizedCmdException extends Exception
{
}
