package phase2Pack.Exceptions;

public class InexistentKeyException extends Exception
{
}
