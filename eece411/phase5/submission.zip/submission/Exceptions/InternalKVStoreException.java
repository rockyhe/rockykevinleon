package phase2Pack.Exceptions;

public class InternalKVStoreException extends Exception
{
}
