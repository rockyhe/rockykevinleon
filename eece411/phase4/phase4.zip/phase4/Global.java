package phase2Pack;

public class Global {
        public static int myIndex;
}
